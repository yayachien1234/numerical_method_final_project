import openai
import markdown
def get_open_ai_api_chat_response(prompt):
  openai.api_key = "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"
  user_prompt = {}
  user_prompt['role'] = 'user'


  if prompt == "n":
    user_prompt['content'] = prompt 
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    
    
    md_file = response["choices"][0]["message"]["content"]
    html = markdown.markdown(md_file, extensions=['tables'])
    
    print(ai_answer)
    print(html)
    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html  
#--------------------------------------------------------------------
  elif prompt == "y":
    user_prompt['content'] = "接下來請分三次問我這三個問題，一次請只問我一個問題就好，1. 請問你是男生還是女生 "
  #"如果（我問的問題是跟電腦有關的問題）請幫我回復我markdown表格的格式並且不要有表格以外的回覆標題有：廠牌、電腦名稱、處理器、顯示卡、螢幕尺寸、適合的消費族群、商品介紹，如果不是跟電腦有關的問題就不需要表格正常用字串直接回復即可"
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    # 服務身上菜了，我們開始吃想要吃的菜，這邊想要吃的菜就是傳回來的答案
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    
    
    md_file = response["choices"][0]["message"]["content"]
    html = markdown.markdown(md_file, extensions=['tables'])

    print(ai_answer)
    print(html)
    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html
#-------------------------------------------------------------------- 
  elif prompt=="男生"or prompt =="女生":
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")

    
    html = markdown.markdown("請問你是學生、文書處理者、工程師、創作者、或是純娛樂")
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  elif prompt == "學生" or prompt == "文書處理者" or prompt == "工程師" or prompt == "創作者" or prompt == "純娛樂使用者":
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    html = markdown.markdown("請問你有重度遊戲需求嗎？(y1/n1)")
    
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  elif prompt == "y1" or prompt == "n1" :
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    html = markdown.markdown("請問你有重度3D繪圖需求嗎？(y2/n2)")
    
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  elif prompt == "y2" or prompt == "n2" :
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    html = markdown.markdown("請問你會很在乎效能嗎？(y3/n3)")
    
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  elif prompt == "y3" or prompt == "n3" :
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    html = markdown.markdown("請問你會很在乎續航嗎？(y4/n4)")
    
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  elif prompt == "y4" or prompt == "n4":
    user_prompt['content'] = prompt
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    html = markdown.markdown("接下來我將會根據您的需求為您推薦一台電腦並且建議您該準備的預算")
    
    print(ai_answer)
    print(html)

    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html 
#--------------------------------------------------------------------
  else:
    user_prompt['content'] = prompt +"如果（我問的問題是跟電腦有關的問題，並且有需要整理成表格會比較好閱讀）請幫我回復我markdown表格的格式並且不要有表格以外的回覆標題有：廠牌、電腦名稱、處理器、顯示卡、螢幕尺寸、適合的消費族群、商品介紹，如果不是跟電腦有關的問題就不需要表格正常用字串直接回復即可"
    messages = []
    messages.append({"role": "assistant", "content": "你是一位電腦挑選助理"})
    messages.append(user_prompt)
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=messages)
    # 服務身上菜了，我們開始吃想要吃的菜，這邊想要吃的菜就是傳回來的答案
    ai_answer = response["choices"][0]["message"]["content"].replace(
      "\n", "<br>")
    
    
    md_file = response["choices"][0]["message"]["content"]
    html = markdown.markdown(md_file, extensions=['tables'])
    
    print(ai_answer)
    print(html)
    # 把答案返迴給呼叫這個方程的地方
    return ai_answer, html